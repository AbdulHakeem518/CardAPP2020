$(document).ready(function(){
    //Password show or hide
    function handler1() {
         $(this).addClass("eye-active");
         $(".eye-active").empty();
         $(".eye-active").append('<i class="fa fa-eye-slash" aria-hidden="true"></i>');
         $(".eye-active").parent(".input-group-text").parent(".input-group").children(".eye-password").attr("type","text");
         $(this).one("click", handler2);
     }
     function handler2() {
         $(".eye-active").empty();
         $(".eye-active").append('<i class="fa fa-eye" aria-hidden="true"></i>');
         $(".eye-active").parent(".input-group-text").parent(".input-group").children(".eye-password").attr("type","password");
         $(".eye-active").removeClass("eye-active");
         $(this).one("click", handler1);
     }
     $(".eye-pass").one("click", handler1);

     //Chainging Color Scheme
     $(".click-me").click(function(){
         $("body:not(.not-chang-clr-scheme)").addClass("light");
         $("body:not(.not-chang-clr-scheme) .login-cont").addClass("light-login-cont");
     });

    //changing pencil icon
    $(".profile-design3 .profile-icon-edit").empty().html('<i class="fa fa-pencil" aria-hidden="true"></i>');
    
    //dropdown in right
    $width = $( window ).width();
    if($width <= 1024){
        $(".profile-right-layout-dsgn1 .profile-box-link  .profile-box-link-info .profile-dropdown .dropdown-menu").addClass("dropdown-menu-right");
    }
    else{
        $(".profile-right-layout-dsgn1 .profile-box-link:nth-child(even)  .profile-box-link-info .profile-dropdown .dropdown-menu").addClass("dropdown-menu-right");
    }
    $(".profile-right-layout-dsgn2 .profile-box-link-info .profile-dropdown .dropdown-menu,.profile-right-layout-dsgn3 .profile-box-link-info .profile-dropdown .dropdown-menu").addClass("dropdown-menu-right");
    
    //removing html when no links are not available in profile-view.html
    $(".profile-right-layout-noLinks").empty().html('<img src="assets/images/noLinks-appear-img.svg" class="img-fluid d-block m-auto">').parent("div").addClass("w-100");
});